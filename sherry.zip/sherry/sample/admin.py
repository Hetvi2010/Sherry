from django.contrib import admin
from .models import InputModel
# Register your models here.
admin.site.register(InputModel)