from django.shortcuts import render
from .models import InputModel
from django.http import JsonResponse, HttpResponse

# Create your views here.
def home(request):
    if request.is_ajax():
        print("I was called")
        name = request.POST.get('username')
        email = request.POST.get('useremail')
        InputModel.objects.create(name=name, email=email)
        return HttpResponse({'msg':'Sucess'})

    elif request.method == "POST":
        name = request.POST.get('fname')
        email = request.POST.get('getemail')
        inp = InputModel.objects.create(name=name, email=email)
        inp.save()
        return render(request, 'index.html')

    else:        
        return render(request, 'index.html')